"""Primitive API helper for CB"""
import requests
from requests.auth import HTTPBasicAuth
import logging
from Settings import URL, LOGIN, PASSWORD
import argparse


class CBApi(object):
    def __init__(self, url, login, password):
        self.url = url
        self.login = login
        self.password = password
        self.session = requests.Session()
        self.get_access_token()

    def get_access_token(self):
        data = {
            "actorId": self.login
        }

        r = self.session.post(self.url + "auth/token", json=data,
                              auth=HTTPBasicAuth(self.login, self.password))
        if r.status_code == 201:
            self.token = r.json()['accessToken']
        else:
            raise ValueError("Did not receive 201 in reply for token")

    def selfCheck(self):
        """Runs a query against /livenessprobe, throws if not 200"""
        headers = {"Authorization": f"Bearer {self.token}",
                   "Content-type": "application/json"}
        r = self.session.get(self.url + "livenessprobe", headers=headers)
        if r.status_code == 200:
            return True
        else:
            r.raise_for_status()

    def method(self, path, verb="GET"):
        # TODO: pagination
        headers = {"Authorization": f"Bearer {self.token}",
                   "Content-type": "application/json"}
        r = self.session.get(self.url + path, headers=headers)
        r.raise_for_status()
        return r.json()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--debug", help="Enable debug logging",
                        action='store_true')

    args = parser.parse_args()
    if not args.debug:
        logging.basicConfig(level=logging.INFO,
                            format='%(asctime)s %(levelname)s %(message)s')
    else:
        import http.client as http_client
        http_client.HTTPConnection.debuglevel = 1
        requests_log = logging.getLogger("requests.packages.urllib3")
        requests_log.setLevel(logging.DEBUG)
        requests_log.propagate = True
        logging.basicConfig(level=logging.DEBUG,
                            format='%(asctime)s %(levelname)s %(message)s')
    logging.info("Starting")
    logging.debug("Setting up")
    cb_api = CBApi(URL, LOGIN, PASSWORD)
    logging.debug("Done setting up")

    logging.info("Running selfcheck")
    cb_api.selfCheck()
    logging.info("Done selfcheck - all good, API works")
